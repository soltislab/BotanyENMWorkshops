var nodeLookup =
[
   {
      "header": "24", 
      "index": 0
   }, 
   {
      "header": "13", 
      "index": 1
   }, 
   {
      "header": "15", 
      "index": 2
   }, 
   {
      "header": "21", 
      "index": 3
   }, 
   {
      "header": "17", 
      "index": 4
   }, 
   {
      "header": "23", 
      "index": 5
   }, 
   {
      "header": "19", 
      "index": 6
   }, 
   {
      "header": "18", 
      "index": 7
   }, 
   {
      "header": "16", 
      "index": 8
   }, 
   {
      "header": "22", 
      "index": 9
   }, 
   {
      "header": "20", 
      "index": 10
   }, 
   {
      "header": "14", 
      "index": 11
   }
]