var projection_info = JSON.parse(`{
   "projections": [
      {
         "species_name": "Aesculus hippocastanum", 
         "image_path": "gridset/sdm/Aesculus hippocastanum/prj_4330904.png", 
         "algorithm_code": "ATT_MAXENT", 
         "gcm_code": null, 
         "alt_pred_code": null, 
         "scenario_code": "worldclim-curr", 
         "epsg": 4326, 
         "prj_id": 4330904, 
         "label": "Aesculus hippocastanum ATT_MAXENT worldclim-curr gridset/sdm/Aesculus hippocastanum/prj_4330904.tif", 
         "date_code": "Curr", 
         "file_path": "gridset/sdm/Aesculus hippocastanum/prj_4330904.tif"
      }, 
      {
         "species_name": "Aesculus chinensis", 
         "image_path": "gridset/sdm/Aesculus chinensis/prj_4330907.png", 
         "algorithm_code": "ATT_MAXENT", 
         "gcm_code": null, 
         "alt_pred_code": null, 
         "scenario_code": "worldclim-curr", 
         "epsg": 4326, 
         "prj_id": 4330907, 
         "label": "Aesculus chinensis ATT_MAXENT worldclim-curr gridset/sdm/Aesculus chinensis/prj_4330907.tif", 
         "date_code": "Curr", 
         "file_path": "gridset/sdm/Aesculus chinensis/prj_4330907.tif"
      }, 
      {
         "species_name": "Aesculus assamica", 
         "image_path": "gridset/sdm/Aesculus assamica/prj_4330909.png", 
         "algorithm_code": "ATT_MAXENT", 
         "gcm_code": null, 
         "alt_pred_code": null, 
         "scenario_code": "worldclim-curr", 
         "epsg": 4326, 
         "prj_id": 4330909, 
         "label": "Aesculus assamica ATT_MAXENT worldclim-curr gridset/sdm/Aesculus assamica/prj_4330909.tif", 
         "date_code": "Curr", 
         "file_path": "gridset/sdm/Aesculus assamica/prj_4330909.tif"
      }, 
      {
         "species_name": "Aesculus turbinata", 
         "image_path": "gridset/sdm/Aesculus turbinata/prj_4330898.png", 
         "algorithm_code": "ATT_MAXENT", 
         "gcm_code": null, 
         "alt_pred_code": null, 
         "scenario_code": "worldclim-curr", 
         "epsg": 4326, 
         "prj_id": 4330898, 
         "label": "Aesculus turbinata ATT_MAXENT worldclim-curr gridset/sdm/Aesculus turbinata/prj_4330898.tif", 
         "date_code": "Curr", 
         "file_path": "gridset/sdm/Aesculus turbinata/prj_4330898.tif"
      }, 
      {
         "species_name": "Aesculus californica", 
         "image_path": "gridset/sdm/Aesculus californica/prj_4330908.png", 
         "algorithm_code": "ATT_MAXENT", 
         "gcm_code": null, 
         "alt_pred_code": null, 
         "scenario_code": "worldclim-curr", 
         "epsg": 4326, 
         "prj_id": 4330908, 
         "label": "Aesculus californica ATT_MAXENT worldclim-curr gridset/sdm/Aesculus californica/prj_4330908.tif", 
         "date_code": "Curr", 
         "file_path": "gridset/sdm/Aesculus californica/prj_4330908.tif"
      }, 
      {
         "species_name": "Aesculus parryi", 
         "image_path": "gridset/sdm/Aesculus parryi/prj_4330902.png", 
         "algorithm_code": "ATT_MAXENT", 
         "gcm_code": null, 
         "alt_pred_code": null, 
         "scenario_code": "worldclim-curr", 
         "epsg": 4326, 
         "prj_id": 4330902, 
         "label": "Aesculus parryi ATT_MAXENT worldclim-curr gridset/sdm/Aesculus parryi/prj_4330902.tif", 
         "date_code": "Curr", 
         "file_path": "gridset/sdm/Aesculus parryi/prj_4330902.tif"
      }, 
      {
         "species_name": "Billia hippocastanum", 
         "image_path": "gridset/sdm/Billia hippocastanum/prj_4330897.png", 
         "algorithm_code": "ATT_MAXENT", 
         "gcm_code": null, 
         "alt_pred_code": null, 
         "scenario_code": "worldclim-curr", 
         "epsg": 4326, 
         "prj_id": 4330897, 
         "label": "Billia hippocastanum ATT_MAXENT worldclim-curr gridset/sdm/Billia hippocastanum/prj_4330897.tif", 
         "date_code": "Curr", 
         "file_path": "gridset/sdm/Billia hippocastanum/prj_4330897.tif"
      }, 
      {
         "species_name": "Aesculus sylvatica", 
         "image_path": "gridset/sdm/Aesculus sylvatica/prj_4330899.png", 
         "algorithm_code": "ATT_MAXENT", 
         "gcm_code": null, 
         "alt_pred_code": null, 
         "scenario_code": "worldclim-curr", 
         "epsg": 4326, 
         "prj_id": 4330899, 
         "label": "Aesculus sylvatica ATT_MAXENT worldclim-curr gridset/sdm/Aesculus sylvatica/prj_4330899.tif", 
         "date_code": "Curr", 
         "file_path": "gridset/sdm/Aesculus sylvatica/prj_4330899.tif"
      }, 
      {
         "species_name": "Aesculus pavia", 
         "image_path": "gridset/sdm/Aesculus pavia/prj_4330900.png", 
         "algorithm_code": "ATT_MAXENT", 
         "gcm_code": null, 
         "alt_pred_code": null, 
         "scenario_code": "worldclim-curr", 
         "epsg": 4326, 
         "prj_id": 4330900, 
         "label": "Aesculus pavia ATT_MAXENT worldclim-curr gridset/sdm/Aesculus pavia/prj_4330900.tif", 
         "date_code": "Curr", 
         "file_path": "gridset/sdm/Aesculus pavia/prj_4330900.tif"
      }, 
      {
         "species_name": "Aesculus parviflora", 
         "image_path": "gridset/sdm/Aesculus parviflora/prj_4330901.png", 
         "algorithm_code": "ATT_MAXENT", 
         "gcm_code": null, 
         "alt_pred_code": null, 
         "scenario_code": "worldclim-curr", 
         "epsg": 4326, 
         "prj_id": 4330901, 
         "label": "Aesculus parviflora ATT_MAXENT worldclim-curr gridset/sdm/Aesculus parviflora/prj_4330901.tif", 
         "date_code": "Curr", 
         "file_path": "gridset/sdm/Aesculus parviflora/prj_4330901.tif"
      }, 
      {
         "species_name": "Aesculus indica", 
         "image_path": "gridset/sdm/Aesculus indica/prj_4330903.png", 
         "algorithm_code": "ATT_MAXENT", 
         "gcm_code": null, 
         "alt_pred_code": null, 
         "scenario_code": "worldclim-curr", 
         "epsg": 4326, 
         "prj_id": 4330903, 
         "label": "Aesculus indica ATT_MAXENT worldclim-curr gridset/sdm/Aesculus indica/prj_4330903.tif", 
         "date_code": "Curr", 
         "file_path": "gridset/sdm/Aesculus indica/prj_4330903.tif"
      }, 
      {
         "species_name": "Aesculus flava", 
         "image_path": "gridset/sdm/Aesculus flava/prj_4330906.png", 
         "algorithm_code": "ATT_MAXENT", 
         "gcm_code": null, 
         "alt_pred_code": null, 
         "scenario_code": "worldclim-curr", 
         "epsg": 4326, 
         "prj_id": 4330906, 
         "label": "Aesculus flava ATT_MAXENT worldclim-curr gridset/sdm/Aesculus flava/prj_4330906.tif", 
         "date_code": "Curr", 
         "file_path": "gridset/sdm/Aesculus flava/prj_4330906.tif"
      }, 
      {
         "species_name": "Aesculus glabra", 
         "image_path": "gridset/sdm/Aesculus glabra/prj_4330905.png", 
         "algorithm_code": "ATT_MAXENT", 
         "gcm_code": null, 
         "alt_pred_code": null, 
         "scenario_code": "worldclim-curr", 
         "epsg": 4326, 
         "prj_id": 4330905, 
         "label": "Aesculus glabra ATT_MAXENT worldclim-curr gridset/sdm/Aesculus glabra/prj_4330905.tif", 
         "date_code": "Curr", 
         "file_path": "gridset/sdm/Aesculus glabra/prj_4330905.tif"
      }
   ], 
   "occurrences": [
      {
         "num_points": 50, 
         "species_name": "Aesculus hippocastanum", 
         "occ_id": 1480896, 
         "file_path": "gridset/sdm/Aesculus hippocastanum/Aesculus hippocastanum.csv"
      }, 
      {
         "num_points": 50, 
         "species_name": "Aesculus chinensis", 
         "occ_id": 1480899, 
         "file_path": "gridset/sdm/Aesculus chinensis/Aesculus chinensis.csv"
      }, 
      {
         "num_points": 30, 
         "species_name": "Aesculus assamica", 
         "occ_id": 1480901, 
         "file_path": "gridset/sdm/Aesculus assamica/Aesculus assamica.csv"
      }, 
      {
         "num_points": 50, 
         "species_name": "Aesculus turbinata", 
         "occ_id": 1480890, 
         "file_path": "gridset/sdm/Aesculus turbinata/Aesculus turbinata.csv"
      }, 
      {
         "num_points": 50, 
         "species_name": "Aesculus californica", 
         "occ_id": 1480900, 
         "file_path": "gridset/sdm/Aesculus californica/Aesculus californica.csv"
      }, 
      {
         "num_points": 50, 
         "species_name": "Aesculus parryi", 
         "occ_id": 1480894, 
         "file_path": "gridset/sdm/Aesculus parryi/Aesculus parryi.csv"
      }, 
      {
         "num_points": 50, 
         "species_name": "Billia hippocastanum", 
         "occ_id": 1480889, 
         "file_path": "gridset/sdm/Billia hippocastanum/Billia hippocastanum.csv"
      }, 
      {
         "num_points": 50, 
         "species_name": "Aesculus sylvatica", 
         "occ_id": 1480891, 
         "file_path": "gridset/sdm/Aesculus sylvatica/Aesculus sylvatica.csv"
      }, 
      {
         "num_points": 50, 
         "species_name": "Aesculus pavia", 
         "occ_id": 1480892, 
         "file_path": "gridset/sdm/Aesculus pavia/Aesculus pavia.csv"
      }, 
      {
         "num_points": 30, 
         "species_name": "Aesculus parviflora", 
         "occ_id": 1480893, 
         "file_path": "gridset/sdm/Aesculus parviflora/Aesculus parviflora.csv"
      }, 
      {
         "num_points": 21, 
         "species_name": "Aesculus indica", 
         "occ_id": 1480895, 
         "file_path": "gridset/sdm/Aesculus indica/Aesculus indica.csv"
      }, 
      {
         "num_points": 50, 
         "species_name": "Aesculus flava", 
         "occ_id": 1480898, 
         "file_path": "gridset/sdm/Aesculus flava/Aesculus flava.csv"
      }, 
      {
         "num_points": 50, 
         "species_name": "Aesculus glabra", 
         "occ_id": 1480897, 
         "file_path": "gridset/sdm/Aesculus glabra/Aesculus glabra.csv"
      }
   ]
}`);