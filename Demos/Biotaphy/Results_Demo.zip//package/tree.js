var taxonTree = `#NEXUS

BEGIN TAXA;
    DIMENSIONS NTAX=13;
    TAXLABELS
        Aesculus_parviflora
[&squid=d4bafb366110504c2b878620d36c99e111c6e6265a4507d87e627eb86e6c8ca8]
        Aesculus_sylvatica
[&squid=5ba18f9e3f29683d39031232e6ecadbdd3d1a52c870ef3af41aa0d5f482f8d87]
        Aesculus_glabra
[&squid=5842449a4fc626670943958ad917e11a699a744b5de3c362c43dc8df166db1df]
        Aesculus_flava
[&squid=430471be1e2ce07dcbb4ff21f68281f56f09dcc14c2c482f15af6cd9455dab9e]
        Aesculus_pavia
[&squid=ab1db720f005f567c1a59bda3411cae60b78f6f439b68f0bd1ab0b9e11ef11f9]
        Aesculus_parryi
[&squid=11b95fbfc192951a1aaa3b949ef15cab3780236f1ed024cc4f2bdc5b1549f00d]
        Aesculus_chinensis
[&squid=7ab2ba76287efcd79ab3d2b75b0222d52d0c0260fac8051bcd49d3e715dc143f]
        Aesculus_assamica
[&squid=ca40ea93744e080a01684c28e98d76010d4e557dbe6820a76416838e6eeaab88]
        Aesculus_indica
[&squid=34e095b363beda6c67c62e536943da0e7e8e28367f5d5f86183fd32077780483]
        Aesculus_californica
[&squid=a40b93e9235d7b1cfa011cd86bcbfecbab92f05fae96b62cbd7549f0dd77c430]
        Aesculus_hippocastanum
[&squid=8ce7174a8fc99f75a688218e4fd8a9fb1ff97fc134bca9d476f6003be6bb7e61]
        Aesculus_turbinata
[&squid=b61302a3a26695e51600edab417d94fefe6819b66fffd99377210b2470e6dfa9]
        Billia_hippocastanum
[&squid=93f181b9636c206c5fb175898d90f6f49b9f0c9ba9715e3ce76e12d0bae343ec]
  ;
END;

BEGIN TREES;
    TREE 1 = (((Aesculus_parviflora:0.849986936606,((Aesculus_sylvatica:0.323500863814,(Aesculus_glabra:0.263988272903,(Aesculus_flava:0.20696199695,Aesculus_pavia:0.20696199695)19:0.0570262782119)18:0.0595125961286)17:0.269052627287,Aesculus_parryi:0.592553490151)16:0.257433436946)15:0.0312710331776,(((Aesculus_chinensis:0.209711717668,(Aesculus_assamica:0.0460241252801,Aesculus_indica:0.0460241252801)23:0.163687588022)22:0.594497947605,Aesculus_californica:0.804209656034)21:0.0213242111479,(Aesculus_hippocastanum:0.216986777772,Aesculus_turbinata:0.216986777772)24:0.608547092041)20:0.055724094625)14:0.118742035204,Billia_hippocastanum:1.0)13;
END;

`;